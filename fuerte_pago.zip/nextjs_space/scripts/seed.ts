import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding database...');

  // Admin user (test account)
  const adminPassword = await bcrypt.hash('johndoe123', 12);
  await prisma.user.upsert({
    where: { email: 'john@doe.com' },
    update: { role: 'ADMIN', password: adminPassword },
    create: {
      email: 'john@doe.com',
      name: 'Administrador',
      password: adminPassword,
      dni: '00000001',
      role: 'ADMIN',
      fcBalance: 10000,
    },
  });

  // Sample client user
  const clientPassword = await bcrypt.hash('cliente123', 12);
  const client1 = await prisma.user.upsert({
    where: { email: 'maria@feria.com' },
    update: {},
    create: {
      email: 'maria@feria.com',
      name: 'Mar\u00eda Garc\u00eda',
      password: clientPassword,
      dni: '30123456',
      role: 'CLIENT',
      fcBalance: 500,
    },
  });

  const client2 = await prisma.user.upsert({
    where: { email: 'carlos@feria.com' },
    update: {},
    create: {
      email: 'carlos@feria.com',
      name: 'Carlos L\u00f3pez',
      password: clientPassword,
      dni: '31654321',
      role: 'CLIENT',
      fcBalance: 300,
    },
  });

  // Sample products
  const productsData = [
    { name: 'Empanadas Caseras (docena)', description: 'Empanadas de carne cortada a cuchillo, bien criollas', price: 25, stock: 20, category: 'Alimentos', sellerId: client1.id, status: 'APPROVED' },
    { name: 'Remera Estampada', description: 'Remera de algod\u00f3n 100% con dise\u00f1o original', price: 15, stock: 50, category: 'Ropa', sellerId: client1.id, status: 'APPROVED' },
    { name: 'Mermelada Artesanal', description: 'Mermelada de frutos rojos, frasco de 500g', price: 10, stock: 30, category: 'Alimentos', sellerId: client2.id, status: 'APPROVED' },
    { name: 'Servicio de Dise\u00f1o Gr\u00e1fico', description: 'Dise\u00f1o de logo profesional para tu emprendimiento', price: 50, stock: 10, category: 'Servicios', sellerId: client2.id, status: 'APPROVED' },
    { name: 'Alfajores Artesanales (caja x12)', description: 'Alfajores de maicena con dulce de leche', price: 18, stock: 40, category: 'Alimentos', sellerId: client1.id, status: 'PENDING' },
    { name: 'Funda para Celular', description: 'Funda personalizada con foto o dise\u00f1o a elecci\u00f3n', price: 8, stock: 100, category: 'Tecnolog\u00eda', sellerId: client2.id, status: 'APPROVED' },
  ];

  for (const p of productsData) {
    const existing = await prisma.product.findFirst({
      where: { name: p.name, sellerId: p.sellerId },
    });
    if (!existing) {
      await prisma.product.create({ data: p });
    }
  }

  console.log('Seed completed!');
}

main()
  .catch((e) => {
    console.error('Seed error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
