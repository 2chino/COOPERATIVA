'use client';

import { Wallet } from 'lucide-react';

export function FcBadge({ amount, size = 'md' }: { amount: number; size?: 'sm' | 'md' | 'lg' }) {
  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5',
    md: 'text-sm px-3 py-1',
    lg: 'text-base px-4 py-1.5',
  };
  return (
    <span className={`inline-flex items-center gap-1 font-mono font-semibold text-green-700 dark:text-green-400 bg-green-50 dark:bg-green-900/30 rounded-full ${sizeClasses[size] ?? sizeClasses.md}`}>
      <Wallet className={size === 'sm' ? 'w-3 h-3' : 'w-4 h-4'} />
      {(amount ?? 0)?.toFixed?.(2) ?? '0.00'} FC
    </span>
  );
}
