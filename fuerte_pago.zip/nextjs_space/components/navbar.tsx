'use client';

import { useSession, signOut } from 'next-auth/react';
import Link from 'next/link';
import { useState, useEffect } from 'react';
import { ShoppingCart, Store, Package, BarChart3, Users, LogOut, Menu, X, Wallet, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function Navbar() {
  const { data: session, status } = useSession() || {};
  const [balance, setBalance] = useState<number>(0);
  const [cartCount, setCartCount] = useState<number>(0);
  const [mobileOpen, setMobileOpen] = useState(false);
  const isAdmin = (session?.user as any)?.role === 'ADMIN';

  useEffect(() => {
    if (status === 'authenticated') {
      fetch('/api/user/balance').then(r => r?.json?.()).then(d => setBalance(d?.fcBalance ?? 0)).catch(() => {});
      fetch('/api/cart').then(r => r?.json?.()).then(d => {
        if (Array.isArray(d)) setCartCount(d.length);
      }).catch(() => {});
    }
  }, [status]);

  if (status !== 'authenticated') return null;

  return (
    <header className="sticky top-0 z-50 bg-white/90 dark:bg-black/90 backdrop-blur-md border-b border-border">
      <div className="max-w-[1200px] mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/marketplace" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
            <span className="text-white font-bold text-sm">FP</span>
          </div>
          <span className="font-display font-bold text-lg tracking-tight text-foreground hidden sm:block">Fuerte Pago</span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-1">
          <Link href="/marketplace">
            <Button variant="ghost" size="sm" className="gap-2">
              <Store className="w-4 h-4" /> Marketplace
            </Button>
          </Link>
          <Link href="/my-products">
            <Button variant="ghost" size="sm" className="gap-2">
              <Package className="w-4 h-4" /> Mis Productos
            </Button>
          </Link>
          <Link href="/transactions">
            <Button variant="ghost" size="sm" className="gap-2">
              <BarChart3 className="w-4 h-4" /> Transacciones
            </Button>
          </Link>
          {isAdmin && (
            <Link href="/admin">
              <Button variant="ghost" size="sm" className="gap-2 text-primary">
                <Users className="w-4 h-4" /> Admin
              </Button>
            </Link>
          )}
        </nav>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 bg-secondary/10 text-secondary-foreground dark:text-green-400 px-3 py-1.5 rounded-full text-sm font-mono font-semibold">
            <Wallet className="w-4 h-4 text-green-700 dark:text-green-400" />
            <span className="text-green-700 dark:text-green-400">{balance?.toFixed?.(2) ?? '0.00'} FC</span>
          </div>
          <Link href="/cart" className="relative">
            <Button variant="ghost" size="icon" className="relative">
              <ShoppingCart className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-primary text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Button>
          </Link>
          <Button variant="ghost" size="sm" onClick={() => signOut({ callbackUrl: '/auth/login' })} className="gap-2 text-muted-foreground">
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">Salir</span>
          </Button>
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
        </div>
      </div>

      {/* Mobile Nav */}
      {mobileOpen && (
        <div className="md:hidden border-t border-border bg-white dark:bg-black p-4 space-y-2">
          <Link href="/marketplace" onClick={() => setMobileOpen(false)}>
            <Button variant="ghost" className="w-full justify-start gap-2"><Store className="w-4 h-4" /> Marketplace</Button>
          </Link>
          <Link href="/my-products" onClick={() => setMobileOpen(false)}>
            <Button variant="ghost" className="w-full justify-start gap-2"><Package className="w-4 h-4" /> Mis Productos</Button>
          </Link>
          <Link href="/transactions" onClick={() => setMobileOpen(false)}>
            <Button variant="ghost" className="w-full justify-start gap-2"><BarChart3 className="w-4 h-4" /> Transacciones</Button>
          </Link>
          {isAdmin && (
            <Link href="/admin" onClick={() => setMobileOpen(false)}>
              <Button variant="ghost" className="w-full justify-start gap-2 text-primary"><Users className="w-4 h-4" /> Admin</Button>
            </Link>
          )}
        </div>
      )}
    </header>
  );
}
