'use client';

import Image from 'next/image';
import { ShoppingCart, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { FcBadge } from '@/components/fc-badge';
import { toast } from 'sonner';
import { useState } from 'react';

interface ProductCardProps {
  product: any;
  currentUserId?: string;
  onAddToCart?: () => void;
}

export function ProductCard({ product, currentUserId, onAddToCart }: ProductCardProps) {
  const [loading, setLoading] = useState(false);
  const isMine = product?.sellerId === currentUserId;
  const outOfStock = (product?.stock ?? 0) <= 0;

  const handleAdd = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId: product?.id, quantity: 1 }),
      });
      const data = await res?.json?.();
      if (res?.ok) {
        toast.success('Agregado al carrito');
        onAddToCart?.();
      } else {
        toast.error(data?.error ?? 'Error al agregar');
      }
    } catch {
      toast.error('Error de conexi\u00f3n');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-200 overflow-hidden group border border-border/50">
      <div className="relative aspect-[4/3] bg-muted overflow-hidden">
        {product?.imageUrl ? (
          <Image
            src={product.imageUrl}
            alt={product?.name ?? 'Producto'}
            fill
            className="object-cover group-hover:scale-105 transition-transform duration-300"
            sizes="(max-width: 768px) 100vw, 33vw"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Package className="w-12 h-12 text-muted-foreground/30" />
          </div>
        )}
        {product?.category && (
          <span className="absolute top-2 left-2 bg-black/60 text-white text-xs px-2 py-1 rounded-full">
            {product.category}
          </span>
        )}
      </div>
      <div className="p-4 space-y-2">
        <h3 className="font-semibold text-foreground truncate">{product?.name ?? 'Sin nombre'}</h3>
        <p className="text-sm text-muted-foreground line-clamp-2">{product?.description ?? ''}</p>
        <div className="flex items-center justify-between">
          <FcBadge amount={product?.price ?? 0} />
          <span className="text-xs text-muted-foreground">Stock: {product?.stock ?? 0}</span>
        </div>
        {product?.seller && (
          <p className="text-xs text-muted-foreground">Vendedor: {product.seller?.name ?? product.seller?.email ?? 'Desconocido'}</p>
        )}
        {!isMine && !outOfStock && (
          <Button
            onClick={handleAdd}
            disabled={loading}
            className="w-full gap-2 bg-primary hover:bg-primary/90 text-white"
            size="sm"
          >
            <ShoppingCart className="w-4 h-4" />
            {loading ? 'Agregando...' : 'Agregar al Carrito'}
          </Button>
        )}
        {outOfStock && (
          <Button disabled className="w-full" size="sm" variant="outline">Agotado</Button>
        )}
        {isMine && (
          <p className="text-xs text-center text-muted-foreground italic">Tu producto</p>
        )}
      </div>
    </div>
  );
}
