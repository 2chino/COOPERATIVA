'use client';

import { useState, useEffect, useCallback } from 'react';
import { useSession } from 'next-auth/react';
import { Plus, Package, Pencil, Trash2, Upload, X, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Navbar } from '@/components/navbar';
import { FcBadge } from '@/components/fc-badge';
import { FadeIn } from '@/components/ui/animate';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import Image from 'next/image';

const CATEGORIES = ['General', 'Alimentos', 'Bebidas', 'Ropa', 'Tecnología', 'Servicios', 'Otros'];

export default function MyProductsPage() {
  const { data: session } = useSession() || {};
  const [products, setProducts] = useState<any[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [form, setForm] = useState({ name: '', description: '', price: '', stock: '', category: 'General' });
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);

  const userId = (session?.user as any)?.id;

  const fetchProducts = useCallback(async () => {
    if (!userId) return;
    setFetching(true);
    try {
      const res = await fetch(`/api/products?status=ALL&sellerId=${userId}`);
      const data = await res?.json?.();
      setProducts(Array.isArray(data) ? data : []);
    } catch { setProducts([]); }
    finally { setFetching(false); }
  }, [userId]);

  useEffect(() => { fetchProducts(); }, [fetchProducts]);

  const updateForm = (field: string, value: string) => setForm(prev => ({ ...(prev ?? {}), [field]: value }));

  const handleImage = (e: any) => {
    const file = e?.target?.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onload = (ev: any) => setImagePreview(ev?.target?.result ?? '');
      reader.readAsDataURL(file);
    }
  };

  const uploadImage = async (): Promise<{ imageUrl: string; cloudStoragePath: string } | null> => {
    if (!imageFile) return null;
    try {
      const presignRes = await fetch('/api/upload/presigned', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fileName: imageFile.name, contentType: imageFile.type, isPublic: true }),
      });
      const { uploadUrl, cloud_storage_path } = await presignRes?.json?.() ?? {};
      if (!uploadUrl) throw new Error('No upload URL');

      await fetch(uploadUrl, {
        method: 'PUT',
        headers: { 'Content-Type': imageFile.type },
        body: imageFile,
      });

      const bucketName = cloud_storage_path?.includes?.('public/') ? process.env.NEXT_PUBLIC_BUCKET : '';
      const region = 'us-west-2';
      const imageUrl = `https://cdn-images-1.medium.com/max/1024/1*BRB0_pxzDH7wnHwiJplvVg.png ?? 'abacusai-apps-74777a80c3756aa4527ffeff-us-west-2'}.s3.${region}.amazonaws.com/${cloud_storage_path}`;

      return { imageUrl, cloudStoragePath: cloud_storage_path };
    } catch (err: any) {
      console.error('Upload error:', err);
      toast.error('Error al subir imagen');
      return null;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.description || !form.price || !form.stock) {
      toast.error('Completá todos los campos');
      return;
    }
    setLoading(true);
    try {
      let imgData: any = {};
      if (imageFile) {
        const uploaded = await uploadImage();
        if (uploaded) {
          imgData.imageUrl = uploaded.imageUrl;
          imgData.cloudStoragePath = uploaded.cloudStoragePath;
        }
      }

      const url = editing ? `/api/products/${editing.id}` : '/api/products';
      const method = editing ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, ...imgData }),
      });
      const data = await res?.json?.();
      if (res?.ok) {
        toast.success(editing ? 'Producto actualizado' : 'Producto creado (pendiente de aprobación)');
        resetForm();
        fetchProducts();
      } else {
        toast.error(data?.error ?? 'Error');
      }
    } catch {
      toast.error('Error de conexión');
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setShowForm(false);
    setEditing(null);
    setForm({ name: '', description: '', price: '', stock: '', category: 'General' });
    setImageFile(null);
    setImagePreview('');
  };

  const startEdit = (p: any) => {
    setEditing(p);
    setForm({
      name: p?.name ?? '',
      description: p?.description ?? '',
      price: String(p?.price ?? ''),
      stock: String(p?.stock ?? ''),
      category: p?.category ?? 'General',
    });
    setImagePreview(p?.imageUrl ?? '');
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('¿Seguro que querés eliminar este producto?')) return;
    try {
      const res = await fetch(`/api/products/${id}`, { method: 'DELETE' });
      if (res?.ok) {
        toast.success('Producto eliminado');
        fetchProducts();
      }
    } catch { toast.error('Error al eliminar'); }
  };

  const statusBadge = (status: string) => {
    const map: Record<string, string> = { PENDING: 'bg-yellow-100 text-yellow-800', APPROVED: 'bg-green-100 text-green-800', REJECTED: 'bg-red-100 text-red-800' };
    const labels: Record<string, string> = { PENDING: 'Pendiente', APPROVED: 'Aprobado', REJECTED: 'Rechazado' };
    return <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${map[status] ?? 'bg-gray-100 text-gray-800'}`}>{labels[status] ?? status}</span>;
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="max-w-[1200px] mx-auto px-4 py-8">
        <FadeIn>
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-display font-bold tracking-tight flex items-center gap-3">
                <Package className="w-8 h-8 text-primary" /> Mis Productos
              </h1>
              <p className="text-muted-foreground">Gestioná tu inventario y publicá nuevos productos</p>
            </div>
            <Button onClick={() => { resetForm(); setShowForm(true); }} className="gap-2 bg-primary hover:bg-primary/90">
              <Plus className="w-4 h-4" /> Nuevo Producto
            </Button>
          </div>
        </FadeIn>

        {showForm && (
          <FadeIn>
            <div className="bg-card rounded-xl shadow-lg p-6 mb-8 border border-border/50">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">{editing ? 'Editar Producto' : 'Nuevo Producto'}</h2>
                <Button variant="ghost" size="icon" onClick={resetForm}><X className="w-5 h-5" /></Button>
              </div>
              <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Nombre</Label>
                  <Input value={form.name} onChange={(e: any) => updateForm('name', e?.target?.value ?? '')} required />
                </div>
                <div className="space-y-2">
                  <Label>Categoría</Label>
                  <select value={form.category} onChange={(e: any) => updateForm('category', e?.target?.value ?? 'General')} className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm">
                    {CATEGORIES.map((c: string) => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>Descripción</Label>
                  <textarea value={form.description} onChange={(e: any) => updateForm('description', e?.target?.value ?? '')} className="w-full min-h-[80px] rounded-md border border-input bg-background px-3 py-2 text-sm" required />
                </div>
                <div className="space-y-2">
                  <Label>Precio (FC)</Label>
                  <Input type="number" step="0.01" min="0" value={form.price} onChange={(e: any) => updateForm('price', e?.target?.value ?? '')} required />
                </div>
                <div className="space-y-2">
                  <Label>Stock</Label>
                  <Input type="number" min="0" value={form.stock} onChange={(e: any) => updateForm('stock', e?.target?.value ?? '')} required />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>Imagen</Label>
                  <div className="flex items-center gap-4">
                    <label className="flex items-center gap-2 px-4 py-2 rounded-md border border-dashed border-muted-foreground/30 cursor-pointer hover:bg-muted/50 transition">
                      <Upload className="w-4 h-4" />
                      <span className="text-sm">{imageFile ? imageFile.name : 'Subir imagen'}</span>
                      <input type="file" accept="image/*" onChange={handleImage} className="hidden" />
                    </label>
                    {imagePreview && (
                      <div className="relative w-16 h-16 rounded-lg overflow-hidden bg-muted">
                        <Image src={imagePreview} alt="Preview" fill className="object-cover" />
                      </div>
                    )}
                  </div>
                </div>
                <div className="md:col-span-2">
                  <Button type="submit" className="gap-2 bg-primary hover:bg-primary/90" disabled={loading}>
                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                    {loading ? 'Guardando...' : editing ? 'Actualizar' : 'Publicar Producto'}
                  </Button>
                </div>
              </form>
            </div>
          </FadeIn>
        )}

        {fetching ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i: number) => <div key={i} className="bg-muted rounded-xl h-48 animate-pulse" />)}
          </div>
        ) : (products?.length ?? 0) === 0 ? (
          <div className="text-center py-20">
            <Package className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-muted-foreground">No tenés productos aún</h3>
            <p className="text-sm text-muted-foreground mb-4">Creá tu primer producto para empezar a vender</p>
            <Button onClick={() => setShowForm(true)} className="gap-2 bg-primary"><Plus className="w-4 h-4" /> Crear Producto</Button>
          </div>
        ) : (
          <div className="space-y-4">
            {(products ?? []).map((p: any) => (
              <div key={p?.id} className="bg-card rounded-xl shadow-sm border border-border/50 p-4 flex flex-col sm:flex-row gap-4 items-start sm:items-center">
                <div className="relative w-20 h-20 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                  {p?.imageUrl ? (
                    <Image src={p.imageUrl} alt={p?.name ?? ''} fill className="object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center"><Package className="w-8 h-8 text-muted-foreground/30" /></div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold truncate">{p?.name ?? 'Sin nombre'}</h3>
                    {statusBadge(p?.status ?? 'PENDING')}
                  </div>
                  <p className="text-sm text-muted-foreground truncate">{p?.description ?? ''}</p>
                  <div className="flex items-center gap-3 mt-1">
                    <FcBadge amount={p?.price ?? 0} size="sm" />
                    <span className="text-xs text-muted-foreground">Stock: {p?.stock ?? 0}</span>
                    <span className="text-xs text-muted-foreground">{p?.category ?? ''}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => startEdit(p)} className="gap-1">
                    <Pencil className="w-3 h-3" /> Editar
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleDelete(p?.id)} className="gap-1 text-destructive hover:text-destructive">
                    <Trash2 className="w-3 h-3" /> Eliminar
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
