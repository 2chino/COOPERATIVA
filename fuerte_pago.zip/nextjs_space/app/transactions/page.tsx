'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { BarChart3, ArrowUpRight, ArrowDownLeft, TrendingUp } from 'lucide-react';
import { Navbar } from '@/components/navbar';
import { FcBadge } from '@/components/fc-badge';
import { FadeIn } from '@/components/ui/animate';
import { format } from 'date-fns';

export default function TransactionsPage() {
  const { data: session } = useSession() || {};
  const [transactions, setTransactions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const userId = (session?.user as any)?.id;

  useEffect(() => {
    fetch('/api/transactions')
      .then(r => r?.json?.())
      .then(d => setTransactions(Array.isArray(d) ? d : []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const totalSpent = (transactions ?? []).filter((t: any) => t?.buyerId === userId).reduce((a: number, t: any) => a + (t?.totalFc ?? 0), 0);
  const totalEarned = (transactions ?? []).filter((t: any) => t?.sellerId === userId).reduce((a: number, t: any) => a + (t?.totalFc ?? 0), 0);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="max-w-[1200px] mx-auto px-4 py-8">
        <FadeIn>
          <h1 className="text-3xl font-display font-bold tracking-tight flex items-center gap-3 mb-2">
            <BarChart3 className="w-8 h-8 text-primary" /> Transacciones
          </h1>
          <p className="text-muted-foreground mb-8">Historial completo de compras y ventas</p>
        </FadeIn>

        <FadeIn delay={0.1}>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
            <div className="bg-card rounded-xl shadow-sm border border-border/50 p-5">
              <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
                <ArrowDownLeft className="w-4 h-4 text-red-500" /> Total Gastado
              </div>
              <p className="text-2xl font-mono font-bold text-red-600">{totalSpent?.toFixed?.(2) ?? '0.00'} FC</p>
            </div>
            <div className="bg-card rounded-xl shadow-sm border border-border/50 p-5">
              <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
                <ArrowUpRight className="w-4 h-4 text-green-500" /> Total Ganado
              </div>
              <p className="text-2xl font-mono font-bold text-green-600">{totalEarned?.toFixed?.(2) ?? '0.00'} FC</p>
            </div>
            <div className="bg-card rounded-xl shadow-sm border border-border/50 p-5">
              <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
                <TrendingUp className="w-4 h-4 text-blue-500" /> Balance Neto
              </div>
              <p className="text-2xl font-mono font-bold">{(totalEarned - totalSpent)?.toFixed?.(2) ?? '0.00'} FC</p>
            </div>
          </div>
        </FadeIn>

        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4].map((i: number) => <div key={i} className="bg-muted rounded-xl h-16 animate-pulse" />)}
          </div>
        ) : (transactions?.length ?? 0) === 0 ? (
          <div className="text-center py-20">
            <BarChart3 className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-muted-foreground">Sin transacciones a\u00fan</h3>
          </div>
        ) : (
          <div className="space-y-3">
            {(transactions ?? []).map((t: any) => {
              const isBuyer = t?.buyerId === userId;
              return (
                <FadeIn key={t?.id}>
                  <div className="bg-card rounded-xl shadow-sm border border-border/50 p-4 flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${isBuyer ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>
                      {isBuyer ? <ArrowDownLeft className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm truncate">
                        {isBuyer ? 'Compraste' : 'Vendiste'}: {t?.product?.name ?? 'Producto'}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {isBuyer ? `Vendedor: ${t?.seller?.name ?? t?.seller?.email ?? ''}` : `Comprador: ${t?.buyer?.name ?? t?.buyer?.email ?? ''}`}
                        {' \u00b7 '}
                        Cant: {t?.quantity ?? 0}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className={`font-mono font-semibold ${isBuyer ? 'text-red-600' : 'text-green-600'}`}>
                        {isBuyer ? '-' : '+'}{(t?.totalFc ?? 0)?.toFixed?.(2)} FC
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {t?.createdAt ? format(new Date(t.createdAt), 'dd/MM/yy HH:mm') : ''}
                      </p>
                    </div>
                  </div>
                </FadeIn>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}
