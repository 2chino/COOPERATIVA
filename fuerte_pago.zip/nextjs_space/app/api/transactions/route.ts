export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) return NextResponse.json({ error: 'No autenticado' }, { status: 401 });
    const userId = (session.user as any).id;
    const role = (session.user as any).role;

    const where = role === 'ADMIN' ? {} : {
      OR: [{ buyerId: userId }, { sellerId: userId }],
    };

    const transactions = await prisma.transaction.findMany({
      where,
      include: {
        buyer: { select: { id: true, name: true, email: true } },
        seller: { select: { id: true, name: true, email: true } },
        product: { select: { id: true, name: true, imageUrl: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: 200,
    });

    return NextResponse.json(transactions);
  } catch (error: any) {
    console.error('Transactions error:', error);
    return NextResponse.json({ error: 'Error' }, { status: 500 });
  }
}
