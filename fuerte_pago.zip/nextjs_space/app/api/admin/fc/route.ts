export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user || (session.user as any).role !== 'ADMIN') {
      return NextResponse.json({ error: 'No autorizado' }, { status: 403 });
    }

    const body = await request.json();
    const { userId, amount, action } = body ?? {};

    if (!userId || amount == null || !action) {
      return NextResponse.json({ error: 'Datos incompletos' }, { status: 400 });
    }

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      return NextResponse.json({ error: 'Monto inv\u00e1lido' }, { status: 400 });
    }

    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 });

    if (action === 'REMOVE' && user.fcBalance < parsedAmount) {
      return NextResponse.json({ error: 'El usuario no tiene suficiente saldo' }, { status: 400 });
    }

    const updated = await prisma.user.update({
      where: { id: userId },
      data: {
        fcBalance: action === 'ADD'
          ? { increment: parsedAmount }
          : { decrement: parsedAmount },
      },
    });

    return NextResponse.json({ success: true, newBalance: updated.fcBalance });
  } catch (error: any) {
    console.error('Admin FC error:', error);
    return NextResponse.json({ error: 'Error' }, { status: 500 });
  }
}
