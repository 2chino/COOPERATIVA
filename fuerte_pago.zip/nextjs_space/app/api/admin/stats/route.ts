export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user || (session.user as any).role !== 'ADMIN') {
      return NextResponse.json({ error: 'No autorizado' }, { status: 403 });
    }

    const [totalUsers, totalProducts, totalTransactions, users, transactions] = await Promise.all([
      prisma.user.count(),
      prisma.product.count(),
      prisma.transaction.count(),
      prisma.user.findMany({ select: { fcBalance: true } }),
      prisma.transaction.findMany({ select: { totalFc: true, createdAt: true }, orderBy: { createdAt: 'desc' }, take: 100 }),
    ]);

    const totalFcCirculation = (users ?? []).reduce((acc: number, u: any) => acc + (u?.fcBalance ?? 0), 0);
    const totalVolume = (transactions ?? []).reduce((acc: number, t: any) => acc + (t?.totalFc ?? 0), 0);
    const pendingProducts = await prisma.product.count({ where: { status: 'PENDING' } });
    const approvedProducts = await prisma.product.count({ where: { status: 'APPROVED' } });

    return NextResponse.json({
      totalUsers,
      totalProducts,
      totalTransactions,
      totalFcCirculation,
      totalVolume,
      pendingProducts,
      approvedProducts,
    });
  } catch (error: any) {
    console.error('Admin stats error:', error);
    return NextResponse.json({ error: 'Error' }, { status: 500 });
  }
}
