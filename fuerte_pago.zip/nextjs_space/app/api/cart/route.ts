export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) return NextResponse.json({ error: 'No autenticado' }, { status: 401 });
    const userId = (session.user as any).id;

    const items = await prisma.cartItem.findMany({
      where: { userId },
      include: {
        product: {
          include: { seller: { select: { id: true, name: true } } },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json(items);
  } catch (error: any) {
    console.error('Cart GET error:', error);
    return NextResponse.json({ error: 'Error' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) return NextResponse.json({ error: 'No autenticado' }, { status: 401 });
    const userId = (session.user as any).id;

    const body = await request.json();
    const { productId, quantity } = body ?? {};
    if (!productId) return NextResponse.json({ error: 'productId requerido' }, { status: 400 });

    const product = await prisma.product.findUnique({ where: { id: productId } });
    if (!product || product.status !== 'APPROVED') {
      return NextResponse.json({ error: 'Producto no disponible' }, { status: 400 });
    }
    if (product.sellerId === userId) {
      return NextResponse.json({ error: 'No puedes comprar tu propio producto' }, { status: 400 });
    }

    const qty = Math.max(1, parseInt(quantity ?? '1'));

    const existing = await prisma.cartItem.findUnique({
      where: { userId_productId: { userId, productId } },
    });

    if (existing) {
      const newQty = existing.quantity + qty;
      if (newQty > product.stock) {
        return NextResponse.json({ error: 'Stock insuficiente' }, { status: 400 });
      }
      const updated = await prisma.cartItem.update({
        where: { id: existing.id },
        data: { quantity: newQty },
      });
      return NextResponse.json(updated);
    }

    if (qty > product.stock) {
      return NextResponse.json({ error: 'Stock insuficiente' }, { status: 400 });
    }

    const item = await prisma.cartItem.create({
      data: { userId, productId, quantity: qty },
    });
    return NextResponse.json(item, { status: 201 });
  } catch (error: any) {
    console.error('Cart POST error:', error);
    return NextResponse.json({ error: 'Error' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) return NextResponse.json({ error: 'No autenticado' }, { status: 401 });
    const userId = (session.user as any).id;

    const { searchParams } = new URL(request.url);
    const itemId = searchParams.get('id');

    if (itemId) {
      await prisma.cartItem.deleteMany({ where: { id: itemId, userId } });
    } else {
      await prisma.cartItem.deleteMany({ where: { userId } });
    }

    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error('Cart DELETE error:', error);
    return NextResponse.json({ error: 'Error' }, { status: 500 });
  }
}
