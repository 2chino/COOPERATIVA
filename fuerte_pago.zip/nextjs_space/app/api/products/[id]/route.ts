export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { deleteFile } from '@/lib/s3';

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const product = await prisma.product.findUnique({
      where: { id: params.id },
      include: { seller: { select: { id: true, name: true, email: true } } },
    });
    if (!product) return NextResponse.json({ error: 'Producto no encontrado' }, { status: 404 });
    return NextResponse.json(product);
  } catch (error: any) {
    console.error('Product GET error:', error);
    return NextResponse.json({ error: 'Error' }, { status: 500 });
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) return NextResponse.json({ error: 'No autenticado' }, { status: 401 });

    const userId = (session.user as any).id;
    const role = (session.user as any).role;
    const product = await prisma.product.findUnique({ where: { id: params.id } });
    if (!product) return NextResponse.json({ error: 'No encontrado' }, { status: 404 });
    if (product.sellerId !== userId && role !== 'ADMIN') {
      return NextResponse.json({ error: 'No autorizado' }, { status: 403 });
    }

    const body = await request.json();
    const data: any = {};
    if (body.name !== undefined) data.name = body.name;
    if (body.description !== undefined) data.description = body.description;
    if (body.price !== undefined) data.price = parseFloat(body.price);
    if (body.stock !== undefined) data.stock = parseInt(body.stock);
    if (body.category !== undefined) data.category = body.category;
    if (body.status !== undefined && role === 'ADMIN') data.status = body.status;
    if (body.imageUrl !== undefined) data.imageUrl = body.imageUrl;
    if (body.cloudStoragePath !== undefined) data.cloudStoragePath = body.cloudStoragePath;

    const updated = await prisma.product.update({ where: { id: params.id }, data });
    return NextResponse.json(updated);
  } catch (error: any) {
    console.error('Product PUT error:', error);
    return NextResponse.json({ error: 'Error al actualizar' }, { status: 500 });
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) return NextResponse.json({ error: 'No autenticado' }, { status: 401 });

    const userId = (session.user as any).id;
    const role = (session.user as any).role;
    const product = await prisma.product.findUnique({ where: { id: params.id } });
    if (!product) return NextResponse.json({ error: 'No encontrado' }, { status: 404 });
    if (product.sellerId !== userId && role !== 'ADMIN') {
      return NextResponse.json({ error: 'No autorizado' }, { status: 403 });
    }

    if (product.cloudStoragePath) {
      try { await deleteFile(product.cloudStoragePath); } catch {}
    }

    await prisma.product.delete({ where: { id: params.id } });
    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error('Product DELETE error:', error);
    return NextResponse.json({ error: 'Error al eliminar' }, { status: 500 });
  }
}
