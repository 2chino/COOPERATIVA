export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status') ?? 'APPROVED';
    const sellerId = searchParams.get('sellerId');
    const category = searchParams.get('category');
    const search = searchParams.get('search');

    const where: any = {};
    if (status !== 'ALL') where.status = status;
    if (sellerId) where.sellerId = sellerId;
    if (category && category !== 'Todos') where.category = category;
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ];
    }

    const products = await prisma.product.findMany({
      where,
      include: { seller: { select: { id: true, name: true, email: true } } },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json(products);
  } catch (error: any) {
    console.error('Products GET error:', error);
    return NextResponse.json({ error: 'Error al obtener productos' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'No autenticado' }, { status: 401 });
    }

    const body = await request.json();
    const { name, description, price, stock, category, imageUrl, cloudStoragePath, isPublicImage } = body ?? {};

    if (!name || !description || price == null || stock == null) {
      return NextResponse.json({ error: 'Campos requeridos incompletos' }, { status: 400 });
    }

    const product = await prisma.product.create({
      data: {
        name,
        description,
        price: parseFloat(price),
        stock: parseInt(stock),
        category: category ?? 'General',
        imageUrl: imageUrl ?? null,
        cloudStoragePath: cloudStoragePath ?? null,
        isPublicImage: isPublicImage ?? true,
        sellerId: (session.user as any).id,
        status: 'PENDING',
      },
    });

    return NextResponse.json(product, { status: 201 });
  } catch (error: any) {
    console.error('Product create error:', error);
    return NextResponse.json({ error: 'Error al crear producto' }, { status: 500 });
  }
}
