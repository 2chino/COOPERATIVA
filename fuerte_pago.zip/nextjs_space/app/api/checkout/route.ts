export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST() {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) return NextResponse.json({ error: 'No autenticado' }, { status: 401 });
    const userId = (session.user as any).id;

    const cartItems = await prisma.cartItem.findMany({
      where: { userId },
      include: { product: true },
    });

    if (!cartItems?.length) {
      return NextResponse.json({ error: 'El carrito est\u00e1 vac\u00edo' }, { status: 400 });
    }

    const buyer = await prisma.user.findUnique({ where: { id: userId } });
    if (!buyer) return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 });

    let totalCost = 0;
    for (const item of cartItems) {
      const p = item?.product;
      if (!p || p.status !== 'APPROVED') {
        return NextResponse.json({ error: `Producto "${p?.name ?? 'desconocido'}" no est\u00e1 disponible` }, { status: 400 });
      }
      if (item.quantity > p.stock) {
        return NextResponse.json({ error: `Stock insuficiente para "${p.name}"` }, { status: 400 });
      }
      totalCost += p.price * item.quantity;
    }

    if (buyer.fcBalance < totalCost) {
      return NextResponse.json({ error: `Saldo FC insuficiente. Necesitas ${totalCost.toFixed(2)} FC` }, { status: 400 });
    }

    // Process transaction atomically
    const result = await prisma.$transaction(async (tx: any) => {
      // Debit buyer
      await tx.user.update({
        where: { id: userId },
        data: { fcBalance: { decrement: totalCost } },
      });

      const transactions = [];
      for (const item of cartItems) {
        const p = item.product;
        // Credit seller
        await tx.user.update({
          where: { id: p.sellerId },
          data: { fcBalance: { increment: p.price * item.quantity } },
        });
        // Decrement stock
        await tx.product.update({
          where: { id: p.id },
          data: { stock: { decrement: item.quantity } },
        });
        // Create transaction record
        const txn = await tx.transaction.create({
          data: {
            buyerId: userId,
            sellerId: p.sellerId,
            productId: p.id,
            quantity: item.quantity,
            unitPrice: p.price,
            totalFc: p.price * item.quantity,
            type: 'PURCHASE',
          },
        });
        transactions.push(txn);
      }

      // Clear cart
      await tx.cartItem.deleteMany({ where: { userId } });

      return transactions;
    });

    return NextResponse.json({ success: true, transactions: result });
  } catch (error: any) {
    console.error('Checkout error:', error);
    return NextResponse.json({ error: 'Error al procesar la compra' }, { status: 500 });
  }
}
