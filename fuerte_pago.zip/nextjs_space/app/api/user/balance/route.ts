export const dynamic = 'force-dynamic';

import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) return NextResponse.json({ error: 'No autenticado' }, { status: 401 });
    const userId = (session.user as any).id;

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { fcBalance: true, name: true, email: true, dni: true, role: true },
    });

    return NextResponse.json(user);
  } catch (error: any) {
    console.error('Balance error:', error);
    return NextResponse.json({ error: 'Error' }, { status: 500 });
  }
}
