'use client';

import { useState, useEffect, useCallback } from 'react';
import { useSession } from 'next-auth/react';
import { Search, SlidersHorizontal, Store } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ProductCard } from '@/components/product-card';
import { Navbar } from '@/components/navbar';
import { FadeIn, Stagger, StaggerItem } from '@/components/ui/animate';

const CATEGORIES = ['Todos', 'General', 'Alimentos', 'Bebidas', 'Ropa', 'Tecnología', 'Servicios', 'Otros'];

export default function MarketplacePage() {
  const { data: session } = useSession() || {};
  const [products, setProducts] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('Todos');
  const [loading, setLoading] = useState(true);

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ status: 'APPROVED' });
      if (search) params.set('search', search);
      if (category !== 'Todos') params.set('category', category);
      const res = await fetch(`/api/products?${params.toString()}`);
      const data = await res?.json?.();
      setProducts(Array.isArray(data) ? data : []);
    } catch {
      setProducts([]);
    } finally {
      setLoading(false);
    }
  }, [search, category]);

  useEffect(() => { fetchProducts(); }, [fetchProducts]);

  const userId = (session?.user as any)?.id;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="max-w-[1200px] mx-auto px-4 py-8">
        <FadeIn>
          <div className="space-y-2 mb-8">
            <h1 className="text-3xl font-display font-bold tracking-tight flex items-center gap-3">
              <Store className="w-8 h-8 text-primary" />
              Moneda Social FC
            </h1>
            <p className="text-muted-foreground">Explorá todos los productos disponibles en la feria</p>
          </div>
        </FadeIn>

        <FadeIn delay={0.1}>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Buscar productos..."
                value={search}
                onChange={(e: any) => setSearch(e?.target?.value ?? '')}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2 flex-wrap">
              {CATEGORIES.map((cat: string) => (
                <Button
                  key={cat}
                  variant={category === cat ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setCategory(cat)}
                  className={category === cat ? 'bg-primary text-white' : ''}
                >
                  {cat}
                </Button>
              ))}
            </div>
          </div>
        </FadeIn>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i: number) => (
              <div key={i} className="bg-muted rounded-xl h-72 animate-pulse" />
            ))}
          </div>
        ) : (products?.length ?? 0) === 0 ? (
          <FadeIn>
            <div className="text-center py-20">
              <Store className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-muted-foreground">No se encontraron productos</h3>
              <p className="text-sm text-muted-foreground">Probá con otros filtros de búsqueda</p>
            </div>
          </FadeIn>
        ) : (
          <Stagger staggerDelay={0.05}>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {(products ?? []).map((product: any) => (
                <StaggerItem key={product?.id ?? Math.random()}>
                  <ProductCard product={product} currentUserId={userId} onAddToCart={fetchProducts} />
                </StaggerItem>
              ))}
            </div>
          </Stagger>
        )}
      </main>
    </div>
  );
}
