'use client';

import { useState } from 'react';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Mail, Lock, User, CreditCard, UserPlus, Chrome } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

export default function SignupPage() {
  const router = useRouter();
  const [form, setForm] = useState({ name: '', email: '', password: '', dni: '' });
  const [loading, setLoading] = useState(false);

  const update = (field: string, value: string) => setForm(prev => ({ ...(prev ?? {}), [field]: value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.password || !form.dni) {
      toast.error('Completá todos los campos');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res?.json?.();
      if (res?.ok) {
        const result = await signIn('credentials', {
          email: form.email,
          password: form.password,
          redirect: false,
        });
        if (result?.ok) {
          router.replace('/marketplace');
        } else {
          toast.error('Registro exitoso, por favor iniciá sesión');
          router.replace('/auth/login');
        }
      } else {
        toast.error(data?.error ?? 'Error al registrar');
      }
    } catch {
      toast.error('Error de conexión');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-red-900/10 via-background to-green-900/10 px-4">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center space-y-2">
          <div className="w-16 h-16 rounded-2xl bg-primary mx-auto flex items-center justify-center shadow-lg">
            <span className="text-white font-bold text-2xl font-display">FP</span>
          </div>
          <h1 className="text-3xl font-display font-bold tracking-tight">Crear Cuenta</h1>
          <p className="text-muted-foreground">Unite a Fuerte Pago</p>
        </div>

        <div className="bg-card rounded-xl shadow-lg p-6 space-y-6 border border-border/50">
          <Button
            variant="outline"
            className="w-full gap-2 h-11"
            onClick={() => signIn('google', { redirect: true, callbackUrl: '/marketplace' })}
          >
            <Chrome className="w-5 h-5" />
            Registrarse con Google
          </Button>

          <div className="relative">
            <div className="absolute inset-0 flex items-center"><span className="w-full border-t" /></div>
            <div className="relative flex justify-center text-xs uppercase"><span className="bg-card px-2 text-muted-foreground">O con email</span></div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nombre Completo</Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input id="name" placeholder="Tu nombre" value={form.name} onChange={(e: any) => update('name', e?.target?.value ?? '')} className="pl-10" required />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input id="email" type="email" placeholder="tu@email.com" value={form.email} onChange={(e: any) => update('email', e?.target?.value ?? '')} className="pl-10" required />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="dni">DNI</Label>
              <div className="relative">
                <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input id="dni" placeholder="12345678" value={form.dni} onChange={(e: any) => update('dni', e?.target?.value ?? '')} className="pl-10" required />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Contraseña</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input id="password" type="password" placeholder="Mínimo 6 caracteres" value={form.password} onChange={(e: any) => update('password', e?.target?.value ?? '')} className="pl-10" required minLength={6} />
              </div>
            </div>
            <Button type="submit" className="w-full gap-2 bg-primary hover:bg-primary/90" disabled={loading}>
              <UserPlus className="w-4 h-4" />
              {loading ? 'Registrando...' : 'Crear Cuenta'}
            </Button>
          </form>

          <p className="text-center text-sm text-muted-foreground">
            ¿Ya tenés cuenta?{' '}
            <Link href="/auth/login" className="text-primary font-medium hover:underline">Iniciá sesión</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
