'use client';

import { useState, useEffect } from 'react';
import { Users, Plus, Minus, Search, Wallet } from 'lucide-react';
import { Navbar } from '@/components/navbar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { FadeIn } from '@/components/ui/animate';
import { toast } from 'sonner';
import { format } from 'date-fns';

export default function AdminUsersPage() {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [fcModal, setFcModal] = useState<any>(null);
  const [fcAmount, setFcAmount] = useState('');
  const [fcLoading, setFcLoading] = useState(false);

  useEffect(() => {
    fetch('/api/admin/users')
      .then(r => r?.json?.())
      .then(d => setUsers(Array.isArray(d) ? d : []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const filtered = (users ?? []).filter((u: any) => {
    const q = (search ?? '').toLowerCase();
    return (u?.name ?? '').toLowerCase().includes(q) || (u?.email ?? '').toLowerCase().includes(q) || (u?.dni ?? '').includes(q);
  });

  const handleFc = async (action: 'ADD' | 'REMOVE') => {
    if (!fcModal || !fcAmount) return;
    setFcLoading(true);
    try {
      const res = await fetch('/api/admin/fc', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: fcModal.id, amount: fcAmount, action }),
      });
      const data = await res?.json?.();
      if (res?.ok) {
        toast.success(`FC ${action === 'ADD' ? 'agregados' : 'retirados'} correctamente. Nuevo saldo: ${data?.newBalance?.toFixed?.(2)} FC`);
        setUsers(prev => (prev ?? []).map((u: any) => u?.id === fcModal?.id ? { ...(u ?? {}), fcBalance: data?.newBalance ?? u?.fcBalance } : u));
        setFcModal(null);
        setFcAmount('');
      } else {
        toast.error(data?.error ?? 'Error');
      }
    } catch { toast.error('Error de conexi\u00f3n'); }
    finally { setFcLoading(false); }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="max-w-[1200px] mx-auto px-4 py-8">
        <FadeIn>
          <h1 className="text-3xl font-display font-bold tracking-tight flex items-center gap-3 mb-2">
            <Users className="w-8 h-8 text-primary" /> Gesti\u00f3n de Usuarios
          </h1>
          <p className="text-muted-foreground mb-6">Administr\u00e1 cuentas y saldos FC de los participantes</p>

          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Buscar por nombre, email o DNI..." value={search} onChange={(e: any) => setSearch(e?.target?.value ?? '')} className="pl-10" />
          </div>
        </FadeIn>

        {/* FC Modal */}
        {fcModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
            <div className="bg-card rounded-xl shadow-lg p-6 max-w-md w-full space-y-4">
              <h2 className="text-lg font-semibold">Gestionar FC - {fcModal?.name ?? fcModal?.email}</h2>
              <p className="text-sm text-muted-foreground">Saldo actual: <span className="font-mono font-semibold text-green-700">{(fcModal?.fcBalance ?? 0)?.toFixed?.(2)} FC</span></p>
              <Input type="number" placeholder="Monto de FC" value={fcAmount} onChange={(e: any) => setFcAmount(e?.target?.value ?? '')} min="0" step="0.01" />
              <div className="flex gap-3">
                <Button onClick={() => handleFc('ADD')} disabled={fcLoading || !fcAmount} className="flex-1 gap-2 bg-green-600 hover:bg-green-700 text-white">
                  <Plus className="w-4 h-4" /> Agregar FC
                </Button>
                <Button onClick={() => handleFc('REMOVE')} disabled={fcLoading || !fcAmount} variant="outline" className="flex-1 gap-2 text-red-600 border-red-300 hover:bg-red-50">
                  <Minus className="w-4 h-4" /> Retirar FC
                </Button>
              </div>
              <Button variant="ghost" onClick={() => { setFcModal(null); setFcAmount(''); }} className="w-full">Cancelar</Button>
            </div>
          </div>
        )}

        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4].map((i: number) => <div key={i} className="bg-muted rounded-xl h-16 animate-pulse" />)}
          </div>
        ) : (
          <div className="bg-card rounded-xl shadow-sm border border-border/50 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-muted/50">
                    <th className="text-left p-3 font-medium">Nombre</th>
                    <th className="text-left p-3 font-medium">Email</th>
                    <th className="text-left p-3 font-medium">DNI</th>
                    <th className="text-left p-3 font-medium">Rol</th>
                    <th className="text-right p-3 font-medium">Saldo FC</th>
                    <th className="text-center p-3 font-medium">Productos</th>
                    <th className="text-left p-3 font-medium">Registro</th>
                    <th className="text-center p-3 font-medium">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {(filtered ?? []).map((u: any) => (
                    <tr key={u?.id} className="border-t border-border/50 hover:bg-muted/30 transition-colors">
                      <td className="p-3 font-medium">{u?.name ?? '-'}</td>
                      <td className="p-3 text-muted-foreground">{u?.email ?? ''}</td>
                      <td className="p-3 font-mono text-xs">{u?.dni ?? '-'}</td>
                      <td className="p-3">
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${u?.role === 'ADMIN' ? 'bg-primary/10 text-primary' : 'bg-blue-100 text-blue-800'}`}>
                          {u?.role === 'ADMIN' ? 'Admin' : 'Cliente'}
                        </span>
                      </td>
                      <td className="p-3 text-right font-mono font-semibold text-green-700">{(u?.fcBalance ?? 0)?.toFixed?.(2)} FC</td>
                      <td className="p-3 text-center">{u?._count?.products ?? 0}</td>
                      <td className="p-3 text-xs text-muted-foreground">{u?.createdAt ? format(new Date(u.createdAt), 'dd/MM/yy') : '-'}</td>
                      <td className="p-3 text-center">
                        <Button size="sm" variant="outline" onClick={() => setFcModal(u)} className="gap-1">
                          <Wallet className="w-3 h-3" /> FC
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
