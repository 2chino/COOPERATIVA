'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Users, Package, BarChart3, Wallet, ShieldCheck, Clock, CheckCircle } from 'lucide-react';
import { Navbar } from '@/components/navbar';
import { Button } from '@/components/ui/button';
import { FadeIn, Stagger, StaggerItem } from '@/components/ui/animate';

export default function AdminPage() {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/admin/stats')
      .then(r => r?.json?.())
      .then(d => setStats(d ?? {}))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const cards = [
    { label: 'Usuarios', value: stats?.totalUsers ?? 0, icon: Users, color: 'bg-blue-500', href: '/admin/users' },
    { label: 'Productos', value: stats?.totalProducts ?? 0, icon: Package, color: 'bg-green-500', href: '/admin/products' },
    { label: 'Transacciones', value: stats?.totalTransactions ?? 0, icon: BarChart3, color: 'bg-purple-500', href: '/admin/transactions' },
    { label: 'FC en Circulaci\u00f3n', value: `${(stats?.totalFcCirculation ?? 0)?.toFixed?.(2)} FC`, icon: Wallet, color: 'bg-yellow-500', href: '#' },
    { label: 'Volumen Total', value: `${(stats?.totalVolume ?? 0)?.toFixed?.(2)} FC`, icon: BarChart3, color: 'bg-red-500', href: '#' },
    { label: 'Pendientes', value: stats?.pendingProducts ?? 0, icon: Clock, color: 'bg-orange-500', href: '/admin/products' },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="max-w-[1200px] mx-auto px-4 py-8">
        <FadeIn>
          <h1 className="text-3xl font-display font-bold tracking-tight flex items-center gap-3 mb-2">
            <ShieldCheck className="w-8 h-8 text-primary" /> Panel de Administraci\u00f3n
          </h1>
          <p className="text-muted-foreground mb-8">Gestion\u00e1 la plataforma, aprobaciones y finanzas</p>
        </FadeIn>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map((i: number) => <div key={i} className="bg-muted rounded-xl h-32 animate-pulse" />)}
          </div>
        ) : (
          <Stagger staggerDelay={0.08}>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
              {cards.map((card: any, idx: number) => (
                <StaggerItem key={idx}>
                  <Link href={card?.href ?? '#'}>
                    <div className="bg-card rounded-xl shadow-md border border-border/50 p-5 hover:shadow-lg transition-shadow cursor-pointer">
                      <div className="flex items-center gap-3 mb-3">
                        <div className={`w-10 h-10 rounded-lg ${card?.color ?? 'bg-gray-500'} flex items-center justify-center`}>
                          {card?.icon ? <card.icon className="w-5 h-5 text-white" /> : null}
                        </div>
                        <span className="text-sm text-muted-foreground">{card?.label ?? ''}</span>
                      </div>
                      <p className="text-2xl font-bold font-mono">{card?.value ?? 0}</p>
                    </div>
                  </Link>
                </StaggerItem>
              ))}
            </div>
          </Stagger>
        )}

        <FadeIn delay={0.3}>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Link href="/admin/users">
              <Button variant="outline" className="w-full h-16 gap-2 text-lg"><Users className="w-5 h-5" /> Gestionar Usuarios</Button>
            </Link>
            <Link href="/admin/products">
              <Button variant="outline" className="w-full h-16 gap-2 text-lg"><Package className="w-5 h-5" /> Gestionar Productos</Button>
            </Link>
            <Link href="/admin/transactions">
              <Button variant="outline" className="w-full h-16 gap-2 text-lg"><BarChart3 className="w-5 h-5" /> Ver Transacciones</Button>
            </Link>
          </div>
        </FadeIn>
      </main>
    </div>
  );
}
