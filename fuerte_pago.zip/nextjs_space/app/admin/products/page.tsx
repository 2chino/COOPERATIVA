'use client';

import { useState, useEffect } from 'react';
import { Package, Check, X, Search, Eye } from 'lucide-react';
import { Navbar } from '@/components/navbar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { FcBadge } from '@/components/fc-badge';
import { FadeIn } from '@/components/ui/animate';
import { toast } from 'sonner';
import Image from 'next/image';

export default function AdminProductsPage() {
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('ALL');
  const [search, setSearch] = useState('');

  const fetchProducts = () => {
    setLoading(true);
    const params = new URLSearchParams({ status: filter });
    if (search) params.set('search', search);
    fetch(`/api/products?${params.toString()}`)
      .then(r => r?.json?.())
      .then(d => setProducts(Array.isArray(d) ? d : []))
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchProducts(); }, [filter, search]);

  const updateStatus = async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/products/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      if (res?.ok) {
        toast.success(`Producto ${status === 'APPROVED' ? 'aprobado' : 'rechazado'}`);
        fetchProducts();
      }
    } catch { toast.error('Error'); }
  };

  const statusBadge = (status: string) => {
    const map: Record<string, string> = { PENDING: 'bg-yellow-100 text-yellow-800', APPROVED: 'bg-green-100 text-green-800', REJECTED: 'bg-red-100 text-red-800' };
    const labels: Record<string, string> = { PENDING: 'Pendiente', APPROVED: 'Aprobado', REJECTED: 'Rechazado' };
    return <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${map[status] ?? ''}`}>{labels[status] ?? status}</span>;
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="max-w-[1200px] mx-auto px-4 py-8">
        <FadeIn>
          <h1 className="text-3xl font-display font-bold tracking-tight flex items-center gap-3 mb-2">
            <Package className="w-8 h-8 text-primary" /> Gesti\u00f3n de Productos
          </h1>
          <p className="text-muted-foreground mb-6">Aprob\u00e1 o rechaz\u00e1 productos de la feria</p>

          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input placeholder="Buscar productos..." value={search} onChange={(e: any) => setSearch(e?.target?.value ?? '')} className="pl-10" />
            </div>
            <div className="flex gap-2">
              {['ALL', 'PENDING', 'APPROVED', 'REJECTED'].map((s: string) => (
                <Button key={s} variant={filter === s ? 'default' : 'outline'} size="sm" onClick={() => setFilter(s)}
                  className={filter === s ? 'bg-primary text-white' : ''}
                >
                  {s === 'ALL' ? 'Todos' : s === 'PENDING' ? 'Pendientes' : s === 'APPROVED' ? 'Aprobados' : 'Rechazados'}
                </Button>
              ))}
            </div>
          </div>
        </FadeIn>

        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i: number) => <div key={i} className="bg-muted rounded-xl h-20 animate-pulse" />)}
          </div>
        ) : (products?.length ?? 0) === 0 ? (
          <div className="text-center py-20">
            <Package className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
            <p className="text-muted-foreground">No hay productos con este filtro</p>
          </div>
        ) : (
          <div className="space-y-3">
            {(products ?? []).map((p: any) => (
              <FadeIn key={p?.id}>
                <div className="bg-card rounded-xl shadow-sm border border-border/50 p-4 flex flex-col sm:flex-row gap-4 items-start sm:items-center">
                  <div className="relative w-16 h-16 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                    {p?.imageUrl ? (
                      <Image src={p.imageUrl} alt={p?.name ?? ''} fill className="object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center"><Package className="w-6 h-6 text-muted-foreground/30" /></div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold truncate">{p?.name ?? ''}</h3>
                      {statusBadge(p?.status ?? '')}
                    </div>
                    <p className="text-xs text-muted-foreground">Vendedor: {p?.seller?.name ?? p?.seller?.email ?? ''}</p>
                    <div className="flex items-center gap-3 mt-1">
                      <FcBadge amount={p?.price ?? 0} size="sm" />
                      <span className="text-xs text-muted-foreground">Stock: {p?.stock ?? 0}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {p?.status === 'PENDING' && (
                      <>
                        <Button size="sm" onClick={() => updateStatus(p?.id, 'APPROVED')} className="gap-1 bg-green-600 hover:bg-green-700 text-white">
                          <Check className="w-3 h-3" /> Aprobar
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => updateStatus(p?.id, 'REJECTED')} className="gap-1 text-red-600">
                          <X className="w-3 h-3" /> Rechazar
                        </Button>
                      </>
                    )}
                    {p?.status === 'APPROVED' && (
                      <Button size="sm" variant="outline" onClick={() => updateStatus(p?.id, 'REJECTED')} className="gap-1 text-red-600">
                        <X className="w-3 h-3" /> Rechazar
                      </Button>
                    )}
                    {p?.status === 'REJECTED' && (
                      <Button size="sm" onClick={() => updateStatus(p?.id, 'APPROVED')} className="gap-1 bg-green-600 hover:bg-green-700 text-white">
                        <Check className="w-3 h-3" /> Aprobar
                      </Button>
                    )}
                  </div>
                </div>
              </FadeIn>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
