'use client';

import { useState, useEffect } from 'react';
import { BarChart3, ArrowUpRight } from 'lucide-react';
import { Navbar } from '@/components/navbar';
import { FadeIn } from '@/components/ui/animate';
import { format } from 'date-fns';

export default function AdminTransactionsPage() {
  const [transactions, setTransactions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/transactions')
      .then(r => r?.json?.())
      .then(d => setTransactions(Array.isArray(d) ? d : []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="max-w-[1200px] mx-auto px-4 py-8">
        <FadeIn>
          <h1 className="text-3xl font-display font-bold tracking-tight flex items-center gap-3 mb-2">
            <BarChart3 className="w-8 h-8 text-primary" /> Todas las Transacciones
          </h1>
          <p className="text-muted-foreground mb-6">Historial completo de la plataforma</p>
        </FadeIn>

        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i: number) => <div key={i} className="bg-muted rounded-xl h-16 animate-pulse" />)}
          </div>
        ) : (transactions?.length ?? 0) === 0 ? (
          <div className="text-center py-20">
            <BarChart3 className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
            <p className="text-muted-foreground">No hay transacciones a\u00fan</p>
          </div>
        ) : (
          <div className="bg-card rounded-xl shadow-sm border border-border/50 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-muted/50">
                    <th className="text-left p-3 font-medium">Fecha</th>
                    <th className="text-left p-3 font-medium">Producto</th>
                    <th className="text-left p-3 font-medium">Comprador</th>
                    <th className="text-left p-3 font-medium">Vendedor</th>
                    <th className="text-center p-3 font-medium">Cant.</th>
                    <th className="text-right p-3 font-medium">Total FC</th>
                  </tr>
                </thead>
                <tbody>
                  {(transactions ?? []).map((t: any) => (
                    <tr key={t?.id} className="border-t border-border/50 hover:bg-muted/30">
                      <td className="p-3 text-xs text-muted-foreground">
                        {t?.createdAt ? format(new Date(t.createdAt), 'dd/MM/yy HH:mm') : '-'}
                      </td>
                      <td className="p-3 font-medium">{t?.product?.name ?? '-'}</td>
                      <td className="p-3 text-muted-foreground">{t?.buyer?.name ?? t?.buyer?.email ?? '-'}</td>
                      <td className="p-3 text-muted-foreground">{t?.seller?.name ?? t?.seller?.email ?? '-'}</td>
                      <td className="p-3 text-center">{t?.quantity ?? 0}</td>
                      <td className="p-3 text-right font-mono font-semibold text-green-700">{(t?.totalFc ?? 0)?.toFixed?.(2)} FC</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
