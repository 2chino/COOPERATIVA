'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { ShoppingCart, Trash2, Minus, Plus, CreditCard, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Navbar } from '@/components/navbar';
import { FcBadge } from '@/components/fc-badge';
import { FadeIn } from '@/components/ui/animate';
import { toast } from 'sonner';
import Image from 'next/image';

export default function CartPage() {
  const router = useRouter();
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [checking, setChecking] = useState(false);

  const fetchCart = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/cart');
      const data = await res?.json?.();
      setItems(Array.isArray(data) ? data : []);
    } catch { setItems([]); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchCart(); }, [fetchCart]);

  const total = (items ?? []).reduce((acc: number, item: any) => acc + ((item?.product?.price ?? 0) * (item?.quantity ?? 0)), 0);

  const removeItem = async (id: string) => {
    try {
      await fetch(`/api/cart?id=${id}`, { method: 'DELETE' });
      fetchCart();
    } catch { toast.error('Error'); }
  };

  const handleCheckout = async () => {
    setChecking(true);
    try {
      const res = await fetch('/api/checkout', { method: 'POST' });
      const data = await res?.json?.();
      if (res?.ok) {
        toast.success('¡Compra realizada exitosamente!');
        fetchCart();
      } else {
        toast.error(data?.error ?? 'Error en la compra');
      }
    } catch {
      toast.error('Error de conexión');
    } finally {
      setChecking(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="max-w-[1200px] mx-auto px-4 py-8">
        <FadeIn>
          <h1 className="text-3xl font-display font-bold tracking-tight flex items-center gap-3 mb-8">
            <ShoppingCart className="w-8 h-8 text-primary" /> Carrito de Compras
          </h1>
        </FadeIn>

        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i: number) => <div key={i} className="bg-muted rounded-xl h-24 animate-pulse" />)}
          </div>
        ) : (items?.length ?? 0) === 0 ? (
          <FadeIn>
            <div className="text-center py-20">
              <ShoppingCart className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-muted-foreground">Tu carrito está vacío</h3>
              <p className="text-sm text-muted-foreground mb-4">Explorá el marketplace para encontrar productos</p>
              <Button onClick={() => router.push('/marketplace')} className="gap-2 bg-primary">Ir al Marketplace</Button>
            </div>
          </FadeIn>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-4">
              {(items ?? []).map((item: any) => (
                <FadeIn key={item?.id}>
                  <div className="bg-card rounded-xl shadow-sm border border-border/50 p-4 flex gap-4 items-center">
                    <div className="relative w-20 h-20 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                      {item?.product?.imageUrl ? (
                        <Image src={item.product.imageUrl} alt={item?.product?.name ?? ''} fill className="object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center"><Package className="w-8 h-8 text-muted-foreground/30" /></div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold truncate">{item?.product?.name ?? 'Producto'}</h3>
                      <p className="text-sm text-muted-foreground">Vendedor: {item?.product?.seller?.name ?? 'Desconocido'}</p>
                      <div className="flex items-center gap-3 mt-1">
                        <FcBadge amount={item?.product?.price ?? 0} size="sm" />
                        <span className="text-xs text-muted-foreground">x{item?.quantity ?? 0}</span>
                        <span className="font-mono text-sm font-semibold text-green-700">
                          = {((item?.product?.price ?? 0) * (item?.quantity ?? 0))?.toFixed?.(2)} FC
                        </span>
                      </div>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => removeItem(item?.id)} className="text-destructive">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </FadeIn>
              ))}
            </div>
            <div className="lg:col-span-1">
              <FadeIn delay={0.2}>
                <div className="bg-card rounded-xl shadow-lg border border-border/50 p-6 space-y-4 sticky top-24">
                  <h2 className="text-xl font-semibold">Resumen</h2>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Productos ({(items?.length ?? 0)})</span>
                      <span className="font-mono">{total?.toFixed?.(2) ?? '0.00'} FC</span>
                    </div>
                    <div className="border-t pt-2 flex justify-between font-semibold">
                      <span>Total</span>
                      <FcBadge amount={total} />
                    </div>
                  </div>
                  <Button onClick={handleCheckout} disabled={checking} className="w-full gap-2 bg-primary hover:bg-primary/90">
                    <CreditCard className="w-4 h-4" />
                    {checking ? 'Procesando...' : 'Confirmar Compra'}
                  </Button>
                </div>
              </FadeIn>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
